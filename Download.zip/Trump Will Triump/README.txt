Bailey Thompson
Trump Will Triump (1.3.5)
14 January 2017

You must play as Donald Trump to conquer the U.S.A. a state at a time by playing various mini-games. Each state
has its own mini-game. If the mini-game is won, the state becomes Republican, and thus red. If the mini-game is
lost,  the  state  becomes  Democrat, and thus blue. Since there are 50 states in the U.S.A., at the end of the
game,  if  25  or  more  states  become Republican, you, Donald Trump, become president of the United States of
America.  However,  if  less  than  25 states are won, you lose the race of presidency to Hillary Clinton, your
rival. Let it be noted that Triump in "Trump Will Triump" was spelled as such on purpose.


If you do not have the Java 8 JRE, please follow these steps.
1. Go to this website: http://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html
2. Accept the license agreement
3. Download the version that best suits your operating system
4. Wait for the download to be completed
5. Start the .jar file in the folder in which you found these instructions